class_name ArmaExport
extends RefCounted
## Writes the trained fly brain as SQF for Arma 3: flybrain_data.sqf (weights + drone settings),
## fn_flybrain.sqf (runtime), init_example.sqf and a README. Drone in assist mode only.

const OUT_DIR := "user://arma_flybrain"

static func _f(a: PackedFloat32Array) -> String:
	var parts := PackedStringArray()
	for x in a:
		parts.append(String.num(x, 6))
	return "[" + ",".join(parts) + "]"

static func _i(a: PackedInt32Array) -> String:
	var parts := PackedStringArray()
	for x in a:
		parts.append(str(x))
	return "[" + ",".join(parts) + "]"

static func build_data(brain: FlyBrain, genome: PackedFloat32Array, spec: BodySpec) -> String:
	var S := spec.n_sensors()
	var C := spec.n_outputs()
	var b := BrainBatch.new(brain, S, C, 1, 1, Body.CTRL_DT, false)      # builds CSR + per-neuron alpha for us
	var n_in := brain.sensory.size() * S
	var n_out := brain.output.size() * C
	var gain := clampf(exp(genome[genome.size() - 1]), 0.1, 2.0)
	var c := spec.drone
	var cfg := "[%d,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s]" % [c.motor_count, String.num(c.body_mass, 6), String.num(c.motor_mass, 6),
		String.num(c.arm_length, 6), String.num(c.max_thrust, 6), String.num(c.motor_tau, 6), String.num(c.drag, 6),
		String.num(c.yaw_coeff, 6), String.num(c.ang_damping, 6), String.num(c.wind, 6), String.num(c.gust, 6),
		String.num(rad_to_deg(c.max_tilt), 6)]
	var parts := PackedStringArray()
	parts.append("%d,%d,%d,%d,%d,%s,%s,%s" % [brain.n, brain.sensory.size(), brain.output.size(), S, C, String.num(gain, 6),
		String.num(BrainBatch.INPUT_SCALE, 6), String.num(BrainBatch.OUTPUT_SCALE, 6)])
	parts.append(_f(b.alpha))
	parts.append(_i(b.sens_of))
	parts.append(_i(brain.output))
	parts.append(_i(b.row_ptr))
	parts.append(_i(b.e_pre))
	parts.append(_f(b.e_w))
	parts.append(_f(genome.slice(0, n_in)))
	parts.append(_f(genome.slice(n_in, n_in + n_out)))
	parts.append(_f(genome.slice(n_in + n_out, n_in + n_out + C)))
	parts.append(cfg)
	return "// FlyBrain data: [n, nIn, nOut, S, C, gain, inScale, outScale, alpha, sensOf, output, rowPtr, ePre, eW, wIn, wOut, bias, droneCfg]\n[" + ",\n".join(parts) + "]\n"

static func export(brain: FlyBrain, genome: PackedFloat32Array, spec: BodySpec) -> Dictionary:
	if spec.kind != "drone" or not spec.drone.assist:
		return {"ok": false, "message": "Arma export supports the drone in assist mode only (walkers need a custom skeleton / animations)."}
	if genome.size() != BrainBatch.genome_size(brain, spec.n_sensors(), spec.n_outputs()):
		return {"ok": false, "message": "Policy does not match this brain / body."}
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(OUT_DIR))
	var files := {
		"flybrain_data.sqf": build_data(brain, genome, spec),
		"fn_flybrain.sqf": FileAccess.get_file_as_string("res://arma/fn_flybrain.sqf"),
		"init_example.sqf": FileAccess.get_file_as_string("res://arma/init_example.sqf"),
		"README_ARMA.txt": FileAccess.get_file_as_string("res://arma/README_ARMA.txt"),
	}
	for name in files:
		var f := FileAccess.open(OUT_DIR.path_join(name), FileAccess.WRITE)
		if f == null:
			return {"ok": false, "message": "Could not write %s" % name}
		f.store_string(files[name])
	var path := ProjectSettings.globalize_path(OUT_DIR)
	var warn := ""
	if brain.pre.size() > 3000:
		warn = "\nWarning: %d synapses is heavy for SQF (aim for under ~3000). Use the small brain preset and retrain." % brain.pre.size()
	return {"ok": true, "path": path, "message": "Exported for Arma 3 to %s (%d neurons, %d synapses).%s" % [path, brain.n, brain.pre.size(), warn]}
