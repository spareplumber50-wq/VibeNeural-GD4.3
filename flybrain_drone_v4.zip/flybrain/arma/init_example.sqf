// Put the whole "flybrain" folder next to your mission's init.sqf:
//   Documents\Arma 3\missions\<YourMission>.<Map>\flybrain\  (4 files)
// In Eden: place any object (a Darter drone "B_UAV_01_F" works well), give it the variable name  drone1,
// and place a second object or unit as target (variable name  target1).  Then add this to init.sqf:

FB_data = call compile preprocessFileLineNumbers "flybrain\flybrain_data.sqf";
call compile preprocessFileLineNumbers "flybrain\fn_flybrain.sqf";

FB_carrot = 3;        // m: far targets are approached in steps
FB_whiskers = true;   // 8 raycast range finders for obstacle avoidance
FB_debug = false;     // true = hint with the brain's sticks and speed
FB_onCrash = { params ["_obj"]; hint "FlyBrain drone crashed"; };

// optional first check, from the debug console or here: prints PASS if the data file and maths are fine
// [] call FB_fnc_selfTest;

// start 2 seconds after mission start. The drone can sit on the ground: it lifts off to the height given above.
[] spawn {
	sleep 2;
	[drone1, target1, 2] call FB_fnc_start;  // 3rd parameter = take off to 2 m first (use 0 if it already starts in the air)
	// target: object | positionASL array | code returning positionASL
};

// later:  [] call FB_fnc_stop;
