/*
	FlyBrain for Arma 3  -  runs the trained fruit-fly connectome as a drone pilot.

	Part 1 (core) is pure math and uses no engine commands.
	Part 2 (glue) moves any object with the brain, using Arma raycasts as the whiskers.

	Usage (init.sqf):
		FB_data = call compile preprocessFileLineNumbers "flybrain\flybrain_data.sqf";
		call compile preprocessFileLineNumbers "flybrain\fn_flybrain.sqf";
		[drone1, target1] call FB_fnc_start;     // target: object | positionASL array | code returning positionASL
		[drone1, target1, 2] call FB_fnc_start;  // same, but first TAKE OFF to 2 m above the start point (works from the ground)
		[] call FB_fnc_stop;                      // to stop

	Optional globals (set before FB_fnc_start):
		FB_carrot   = 3;      // far targets are approached in steps of this many metres
		FB_whiskers = true;   // 8 raycast range finders (obstacle avoidance); false = blind, faster
		FB_debug    = false;  // hint with brain stats
		FB_takeoff  = 0;      // metres to climb first (0 = start in the air); the 3rd parameter of FB_fnc_start overrides it
		FB_onCrash  = {};     // code, called with [object] when the drone hits something
*/

// ============================================================ part 1: core
// Simulation frame (same as the Godot trainer): x east, y up, z south.  Body axes (bx right, by up, bz back)
// are stored as vectors in that frame.  All angles passed to sin/cos/tan are converted to degrees.

FB_fnc_tanh = {
	private _c = ((_this max (-10)) min 10);
	private _e = exp (2 * _c);
	(_e - 1) / (_e + 1)
};

// _this = cfg array from the data file; builds the physical constants in FB_P
FB_fnc_initParams = {
	_this params ["_mc", "_bodyMass", "_motorMass", "_arm", "_tmax", "_tau", "_drag", "_yawc", "_angd", "_wind", "_gust", "_maxTiltDeg"];
	private _mass = _bodyMass + _motorMass * _mc;
	private _ib = 0.4 * _bodyMass * 0.0025;
	private _ix = _ib;
	private _iy = _ib;
	private _iz = _ib;
	private _sx = 0;
	private _sz = 0;
	private _mpos = [];
	private _mdir = [];
	for "_i" from 0 to (_mc - 1) do {
		private _a = 360 * (_i + 0.5) / _mc;
		private _px = (cos _a) * _arm;
		private _pz = (sin _a) * _arm;
		_mpos pushBack [_px, 0, _pz];
		_mdir pushBack (if ((_i mod 2) == 0) then {1} else {-1});
		_ix = _ix + _motorMass * _pz * _pz;
		_iz = _iz + _motorMass * _px * _px;
		_iy = _iy + _motorMass * (_px * _px + _pz * _pz);
		_sx = _sx + (_px / _arm) * (_px / _arm);
		_sz = _sz + (_pz / _arm) * (_pz / _arm);
	};
	private _wa = random 360;
	private _windVec = [(cos _wa) * _wind, 0, (sin _wa) * _wind];
	private _hover = _mass * 9.81 / (_mc * _tmax);
	FB_P = [_mc, _mass, _arm, _tmax, _tau, _drag, _yawc, _angd, _ix, _iy, _iz, _mpos, _mdir, _windVec, _gust, _maxTiltDeg, _sx, _sz, _hover];
};

// instance = [pos, vel, bx, by, bz, omega(body), thrust[], gust, x[], r[], crashed]
FB_fnc_newInst = {
	params ["_pos", "_vel", "_bx", "_by", "_bz"];
	private _n = FB_data select 0;
	private _mc = FB_P select 0;
	private _th = [];
	for "_i" from 1 to _mc do { _th pushBack ((FB_P select 1) * 9.81 / _mc) };
	private _x = [];
	private _r = [];
	for "_i" from 1 to _n do { _x pushBack 0; _r pushBack 0 };
	[_pos, _vel, _bx, _by, _bz, [0, 0, 0], _th, [0, 0, 0], _x, _r, false]
};

// rotate vector v about unit axis k: _c = cos, _sn = sin of the angle
FB_fnc_rot = {
	params ["_v", "_k", "_c", "_sn"];
	((_v vectorMultiply _c) vectorAdd ((_k vectorCrossProduct _v) vectorMultiply _sn)) vectorAdd (_k vectorMultiply ((_k vectorDotProduct _v) * (1 - _c)))
};

// one 20 ms control tick of rigid-body physics (4 sub-steps), motors cmd 0..1
FB_fnc_physStep = {
	params ["_s", "_cmd", "_dt"];
	FB_P params ["_mc", "_mass", "_arm", "_tmax", "_tau", "_drag", "_yawc", "_angd", "_ix", "_iy", "_iz", "_mpos", "_mdir", "_wind", "_gustAmp"];
	_s params ["_pos", "_vel", "_bx", "_by", "_bz", "_om", "_th", "_gust"];
	private _h = _dt / 4;
	private _lag = (_h / _tau) min 1;
	for "_sub" from 1 to 4 do {
		private _tot = 0;
		private _tx = 0;
		private _ty = 0;
		private _tz = 0;
		for "_i" from 0 to (_mc - 1) do {
			private _tt = (((_cmd select _i) max 0) min 1) * _tmax;
			private _cur = (_th select _i) + (_tt - (_th select _i)) * _lag;
			_th set [_i, _cur];
			_tot = _tot + _cur;
			private _p = _mpos select _i;
			_tx = _tx - (_p select 2) * _cur;
			_ty = _ty + (_mdir select _i) * _yawc * _cur;
			_tz = _tz + (_p select 0) * _cur;
		};
		_tx = _tx - (_om select 0) * _angd;
		_ty = _ty - (_om select 1) * _angd;
		_tz = _tz - (_om select 2) * _angd;
		private _air = _wind vectorAdd _gust;
		private _f = ((_by vectorMultiply _tot) vectorAdd [0, -_mass * 9.81, 0]) vectorAdd ((_air vectorDiff _vel) vectorMultiply _drag);
		_vel = _vel vectorAdd (_f vectorMultiply (_h / _mass));
		_pos = _pos vectorAdd (_vel vectorMultiply _h);
		private _iw = [_ix * (_om select 0), _iy * (_om select 1), _iz * (_om select 2)];
		private _cr = _om vectorCrossProduct _iw;
		_om = [
			(_om select 0) + ((_tx - (_cr select 0)) / _ix) * _h,
			(_om select 1) + ((_ty - (_cr select 1)) / _iy) * _h,
			(_om select 2) + ((_tz - (_cr select 2)) / _iz) * _h
		];
		private _w = vectorMagnitude _om;
		private _ang = _w * _h;
		if (_ang > 1e-9) then {
			private _kb = _om vectorMultiply (1 / _w);
			private _kw = ((_bx vectorMultiply (_kb select 0)) vectorAdd (_by vectorMultiply (_kb select 1))) vectorAdd (_bz vectorMultiply (_kb select 2));
			private _deg = _ang * 57.29577951;
			private _c = cos _deg;
			private _sn = sin _deg;
			_bx = [_bx, _kw, _c, _sn] call FB_fnc_rot;
			_by = [_by, _kw, _c, _sn] call FB_fnc_rot;
			_bz = [_bz, _kw, _c, _sn] call FB_fnc_rot;
		};
	};
	if (_gustAmp > 0) then {
		private _k = 1 - _dt / 1.5;
		private _q = sqrt (2 * _dt / 1.5) * _gustAmp;
		private _rn = {sqrt (-2 * ln (0.0001 + random 1)) * cos (random 360)};
		_gust = [(_gust select 0) * _k + (call _rn) * _q, (_gust select 1) * _k + (call _rn) * _q * 0.3, (_gust select 2) * _k + (call _rn) * _q];
	};
	// keep the body axes orthonormal
	_by = vectorNormalized _by;
	_bx = vectorNormalized (_bx vectorDiff (_by vectorMultiply (_bx vectorDotProduct _by)));
	_bz = _bx vectorCrossProduct _by;
	_s set [0, _pos];
	_s set [1, _vel];
	_s set [2, _bx];
	_s set [3, _by];
	_s set [4, _bz];
	_s set [5, _om];
	_s set [7, _gust];
	if ((_by select 1) < 0 || _pos select 1 != _pos select 1) then { _s set [10, true] };
};

// brain sticks [accel_x, accel_z, yaw_rate, climb] (-1..1)  ->  4..8 motor commands (onboard flight controller)
FB_fnc_stabilize = {
	params ["_s", "_stick"];
	FB_P params ["_mc", "_mass", "_arm", "_tmax", "_tau", "_drag", "_yawc", "_angd", "_ix", "_iy", "_iz", "_mpos", "_mdir", "_wind", "_gustAmp", "_maxTiltDeg", "_sx", "_sz", "_hover"];
	_s params ["_pos", "_vel", "_bx", "_by", "_bz", "_om"];
	private _hl = sqrt ((_bx select 0) * (_bx select 0) + (_bx select 2) * (_bx select 2));
	private _cx = 1;
	private _cz = 0;
	if (_hl > 0.05) then { _cx = (_bx select 0) / _hl; _cz = (_bx select 2) / _hl };
	private _mt = tan _maxTiltDeg;
	private _a = (_stick select 0) * _mt;
	private _b = (_stick select 1) * _mt;
	private _ux = _a * _cx - _b * _cz;
	private _uz = _a * _cz + _b * _cx;
	private _ul = sqrt (_ux * _ux + 1 + _uz * _uz);
	private _upDes = [_ux / _ul, 1 / _ul, _uz / _ul];
	private _da = _upDes vectorDotProduct _bx;
	private _dc = _upDes vectorDotProduct _bz;
	private _wn = 14;
	private _zt = 0.8;
	private _tauX = _ix * (_wn * _wn * _dc - 2 * _zt * _wn * (_om select 0));
	private _tauZ = _iz * (_wn * _wn * (-_da) - 2 * _zt * _wn * (_om select 2));
	private _tauY = _iy * 8 * ((_stick select 2) * 2 - (_om select 1));
	private _uX = _tauX / (_tmax * _arm * (_sz max 0.01));
	private _uZ = _tauZ / (_tmax * _arm * (_sx max 0.01));
	private _uY = _tauY / (_yawc * _tmax * _mc);
	private _thr = _hover * (1 + 0.5 * (_stick select 3)) / ((_by select 1) max 0.5);
	private _cmd = [];
	for "_i" from 0 to (_mc - 1) do {
		private _p = _mpos select _i;
		private _pnx = (_p select 0) / _arm;
		private _pnz = (_p select 2) / _arm;
		_cmd pushBack ((((_thr - _uX * _pnz + _uZ * _pnx + _uY * (_mdir select _i)) max 0) min 1));
	};
	_cmd
};

// 12 body sensors + whisker proximities -> 20 values for the brain.  _target in the simulation frame.
FB_fnc_sense = {
	params ["_s", "_target", "_whisk"];
	_s params ["_pos", "_vel", "_bx", "_by", "_bz", "_om"];
	private _rel = _target vectorDiff _pos;
	private _v = [
		(_rel vectorDotProduct _bx) / 2, (_rel vectorDotProduct _by) / 2, (_rel vectorDotProduct _bz) / 2,
		(_vel vectorDotProduct _bx) / 3, (_vel vectorDotProduct _by) / 3, (_vel vectorDotProduct _bz) / 3,
		(_bx select 1), (_by select 1), (_bz select 1),
		(_om select 0) / 5, (_om select 1) / 5, (_om select 2) / 5
	];
	_v = _v apply { (_x max (-1)) min 1 };
	if (!(_whisk isEqualType []) || { count _whisk != 8 }) then { _whisk = [0, 0, 0, 0, 0, 0, 0, 0] };
	_v append _whisk;
	_v
};

// one brain tick for the connectome.  _x, _r are the neuron states (arrays, x is updated in place).
// returns [newRates, outputs(4)]
FB_fnc_brainStep = {
	params ["_d", "_x", "_r", "_sens"];
	_d params ["_n", "_nIn", "_nOut", "_S", "_C", "_gain", "_inS", "_outS", "_alpha", "_sensOf", "_output", "_rowPtr", "_ePre", "_eW", "_wIn", "_wOut", "_bias"];
	private _rNew = [];
	for "_j" from 0 to (_n - 1) do {
		private _acc = 0;
		private _k = _sensOf select _j;
		if (_k >= 0) then {
			private _b = _k * _S;
			private _sm = 0;
			for "_i" from 0 to (_S - 1) do { _sm = _sm + (_wIn select (_b + _i)) * (_sens select _i) };
			_acc = _sm * _inS;
		};
		private _rec = 0;
		for "_e" from (_rowPtr select _j) to ((_rowPtr select (_j + 1)) - 1) do {
			_rec = _rec + (_eW select _e) * (_r select (_ePre select _e));
		};
		_acc = _acc + _rec * _gain;
		private _xv = (_x select _j) + (_acc - (_x select _j)) * (_alpha select _j);
		_x set [_j, _xv];
		_rNew pushBack (_xv call FB_fnc_tanh);
	};
	private _out = [];
	for "_m" from 0 to (_C - 1) do {
		private _sm = 0;
		for "_k" from 0 to (_nOut - 1) do {
			_sm = _sm + (_wOut select (_k * _C + _m)) * (_rNew select (_output select _k));
		};
		_out pushBack ((_outS * _sm + (_bias select _m)) call FB_fnc_tanh);
	};
	[_rNew, _out]
};

// ============================================================ part 2: Arma glue
if (isNil "FB_toActive") then { FB_toActive = false };
if (isNil "FB_takeoff") then { FB_takeoff = 0 };
if (isNil "FB_toUntil") then { FB_toUntil = 0 };
FB_toSim = { params ["_a"]; [_a select 0, _a select 2, -(_a select 1)] };      // Arma (E,N,U) -> sim (x,y,z)
FB_toArma = { params ["_v"]; [_v select 0, -(_v select 2), _v select 1] };      // sim -> Arma

FB_fnc_whiskers = {
	private _inst = FB_inst;
	private _bx = _inst select 2;
	private _bz = _inst select 4;
	private _from = FB_origin vectorAdd ([_inst select 0] call FB_toArma);
	private _res = [];
	if (FB_whiskers && !(missionNamespace getVariable ["FB_toActive", false])) then {
		for "_k" from 0 to 7 do {
			private _a = 45 * _k;
			private _dir = ((_bx vectorMultiply (sin _a)) vectorAdd (_bz vectorMultiply (-(cos _a))));
			private _to = _from vectorAdd (([_dir] call FB_toArma) vectorMultiply 3);
			private _hit = lineIntersectsSurfaces [_from, _to, FB_obj, objNull, true, 1, "GEOM", "NONE"];
			private _dist = 3;
			if (_hit isEqualType [] && { count _hit > 0 }) then { _dist = _from vectorDistance ((_hit select 0) select 0) };
			_res pushBack (1 - ((_dist min 3) / 3));
		};
	} else {
		_res = [0, 0, 0, 0, 0, 0, 0, 0];
	};
	_res
};

FB_fnc_targetSim = {
	private _res = nil;
	if (FB_toActive) then {
		if (((FB_inst select 0) select 1) >= FB_takeoff - 0.35 || time > FB_toUntil) then {
			FB_toActive = false;
		} else {
			_res = [0, FB_takeoff, 0];       // straight above the start point
		};
	};
	if (isNil "_res") then {
		private _t = FB_target;
		private _asl = switch (true) do {
			case (_t isEqualType objNull): { getPosASL _t };
			case (_t isEqualType {}): { call _t };
			default { _t };
		};
		_res = [_asl vectorDiff FB_origin] call FB_toSim;
	};
	_res
};

FB_fnc_tick = {
	private _inst = FB_inst;
	private _pos = _inst select 0;
	private _tgt = call FB_fnc_targetSim;
	private _rel = _tgt vectorDiff _pos;
	private _dist = vectorMagnitude _rel;
	if (_dist > FB_carrot) then { _tgt = _pos vectorAdd (_rel vectorMultiply (FB_carrot / _dist)) };
	private _sens = [_inst, _tgt, call FB_fnc_whiskers] call FB_fnc_sense;
	if (count _sens != (FB_data select 3)) exitWith {
		[format ["brain expects %1 sensor values but got %2 (re-export the brain from the same app version)", FB_data select 3, count _sens]] call FB_fnc_fail;
	};
	private _res = [FB_data, _inst select 8, _inst select 9, _sens] call FB_fnc_brainStep;
	_inst set [9, _res select 0];
	FB_stick = _res select 1;
	private _cmd = [_inst, FB_stick] call FB_fnc_stabilize;
	private _oldASL = FB_origin vectorAdd ([_pos] call FB_toArma);
	[_inst, _cmd, 0.02] call FB_fnc_physStep;
	private _newASL = FB_origin vectorAdd ([_inst select 0] call FB_toArma);
	if (FB_toActive) then {
		// still lifting off: the ground holds the drone up (no crash, no whiskers)
		private _p = _inst select 0;
		if ((_p select 1) < 0) then {
			_p set [1, 0];
			private _v = _inst select 1;
			if ((_v select 1) < 0) then { _v set [1, 0] };
		};
	} else {
		private _hit = lineIntersectsSurfaces [_oldASL, _newASL, FB_obj, objNull, true, 1, "GEOM", "NONE"];
		if (count _hit > 0 || (_newASL select 2) < (getTerrainHeightASL [_newASL select 0, _newASL select 1]) + 0.05) then {
			_inst set [10, true];
		};
	};
};

FB_fnc_frame = {
	private _t = time;
	private _dt = (_t - FB_last) max 0;
	FB_last = _t;
	FB_acc = FB_acc + (_dt min 0.1);
	private _steps = 0;
	while { FB_acc >= 0.02 && _steps < 3 && !(FB_inst select 10) } do {
		FB_acc = FB_acc - 0.02;
		_steps = _steps + 1;
		call FB_fnc_tick;
	};
	private _inst = FB_inst;
	if (!([_inst select 0] call FB_fnc_okVec) || !([_inst select 3] call FB_fnc_okVec) || !([_inst select 4] call FB_fnc_okVec)) exitWith {
		["simulation state became invalid (NaN / nil); stopped. Check the RPT log for the first error above this one."] call FB_fnc_fail;
	};
	FB_obj setPosASL (FB_origin vectorAdd ([_inst select 0] call FB_toArma));
	FB_obj setVectorDirAndUp [[(_inst select 4) vectorMultiply -1] call FB_toArma, [_inst select 3] call FB_toArma];
	if (FB_debug) then {
		hintSilent format ["FlyBrain\nsticks %1\nspeed %2 m/s", FB_stick apply { _x toFixed 2 }, (vectorMagnitude (_inst select 1)) toFixed 2];
	};
	if (_inst select 10) then {
		private _vel = [_inst select 1] call FB_toArma;
		call FB_fnc_stop;
		FB_obj setVelocity _vel;
		[FB_obj] call (missionNamespace getVariable ["FB_onCrash", {}]);
	};
};

FB_fnc_okVec = {
	params ["_v"];
	private _ok = _v isEqualType [] && { count _v == 3 };
	if (_ok) then {
		{ if (!(_x isEqualType 0) || { _x != _x }) exitWith { _ok = false } } forEach _v;
	};
	_ok
};

FB_fnc_fail = {
	params ["_msg"];
	diag_log ("FlyBrain ERROR: " + _msg);
	systemChat ("FlyBrain ERROR: " + _msg);
	call FB_fnc_stop;
};

// checks that the data file is complete and consistent; returns "" if fine, else the problem
FB_fnc_check = {
	if (isNil "FB_data") exitWith { "FB_data is missing: load flybrain_data.sqf first" };
	if (!(FB_data isEqualType []) || { count FB_data != 18 }) exitWith { "flybrain_data.sqf has the wrong shape (expected 18 entries, re-export it)" };
	FB_data params ["_n", "_nIn", "_nOut", "_S", "_C", "_gain", "_inS", "_outS", "_alpha", "_sensOf", "_output", "_rowPtr", "_ePre", "_eW", "_wIn", "_wOut", "_bias", "_cfg"];
	if (_S != 20) exitWith { format ["brain was exported with %1 sensors, this runtime needs 20", _S] };
	if (_C != 4) exitWith { "brain must be a drone in assist mode (4 stick outputs)" };
	if (count _alpha != _n || count _sensOf != _n || count _rowPtr != (_n + 1)) exitWith { "neuron tables have inconsistent sizes" };
	if (count _wIn != _nIn * _S || count _wOut != _nOut * _C || count _bias != _C) exitWith { "weight tables have inconsistent sizes" };
	if (count _ePre != count _eW || (_rowPtr select _n) != count _eW) exitWith { "synapse tables have inconsistent sizes" };
	if (count _cfg != 12) exitWith { "drone settings have the wrong size" };
	""
};

FB_fnc_stop = {
	if (!isNil "FB_ehId") then {
		removeMissionEventHandler ["EachFrame", FB_ehId];
		FB_ehId = nil;
	};
	if (!isNil "FB_obj") then { if (!isNull FB_obj) then { FB_obj enableSimulation true } };
};

FB_fnc_start = {
	params ["_obj", "_target", ["_takeoff", -1]];
	private _problem = call FB_fnc_check;
	if (_problem != "") exitWith { [_problem] call FB_fnc_fail };
	if (isNil "_obj" || { !(_obj isEqualType objNull) } || { isNull _obj }) exitWith { ["first argument must be the drone object (is its variable name right?)"] call FB_fnc_fail };
	if (isNil "_target") exitWith { ["second argument must be a target: object, positionASL array or code"] call FB_fnc_fail };
	call FB_fnc_stop;
	if (isNil "FB_carrot") then { FB_carrot = 3 };
	if (isNil "FB_whiskers") then { FB_whiskers = true };
	if (isNil "FB_debug") then { FB_debug = false };
	if (_takeoff >= 0) then { FB_takeoff = _takeoff };
	if (isNil "FB_takeoff") then { FB_takeoff = 0 };
	FB_toActive = FB_takeoff > 0;
	FB_toUntil = time + 10;
	FB_obj = _obj;
	FB_target = _target;
	FB_origin = getPosASL _obj;
	(FB_data select 17) call FB_fnc_initParams;
	private _by = vectorNormalized ([vectorUp _obj] call FB_toSim);
	private _bz = vectorNormalized (([vectorDir _obj] call FB_toSim) vectorMultiply -1);
	private _bx = vectorNormalized (_by vectorCrossProduct _bz);
	_bz = _bx vectorCrossProduct _by;
	FB_inst = [[0, 0, 0], [0, 0, 0], _bx, _by, _bz] call FB_fnc_newInst;
	FB_stick = [0, 0, 0, 0];
	FB_last = time;
	FB_acc = 0;
	_obj enableSimulation false;
	FB_ehId = addMissionEventHandler ["EachFrame", { call FB_fnc_frame }];
};

// [] call FB_fnc_selfTest   -> runs 3 simulated seconds without any object; prints PASS / the first problem
FB_fnc_selfTest = {
	private _problem = call FB_fnc_check;
	if (_problem != "") exitWith { systemChat ("FlyBrain selftest FAILED: " + _problem); diag_log ("FlyBrain selftest FAILED: " + _problem); false };
	(FB_data select 17) call FB_fnc_initParams;
	private _inst = [[0, 0, 0], [0, 0, 0], [1, 0, 0], [0, 1, 0], [0, 0, 1]] call FB_fnc_newInst;
	private _w = [0, 0, 0, 0, 0, 0, 0, 0];
	for "_t" from 1 to 150 do {
		private _s = [_inst, [0, 1, 0], _w] call FB_fnc_sense;
		if (count _s != 20) exitWith { systemChat format ["FlyBrain selftest FAILED: sensors %1", count _s] };
		private _res = [FB_data, _inst select 8, _inst select 9, _s] call FB_fnc_brainStep;
		_inst set [9, _res select 0];
		[_inst, [_inst, _res select 1] call FB_fnc_stabilize, 0.02] call FB_fnc_physStep;
	};
	private _ok = [_inst select 0] call FB_fnc_okVec;
	private _msg = format ["FlyBrain selftest %1: after 3 s pos %2", ["FAILED (NaN)", "PASS"] select _ok, (_inst select 0) apply { _x toFixed 2 }];
	systemChat _msg;
	diag_log _msg;
	_ok
};
