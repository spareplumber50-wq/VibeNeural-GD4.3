FlyBrain for Arma 3
===================
Files
  flybrain_data.sqf  the trained brain (weights, wiring) + the drone's settings
  fn_flybrain.sqf    the runtime: the same drone physics and flight controller the brain was trained on,
                     plus Arma glue (8 raycast whiskers, terrain / object collision, moves any object)
  init_example.sqf   copy its lines into your mission's init.sqf

How it works
  The brain does not use Arma's vehicle physics. The script simulates the drone the brain was trained for,
  inside SQF, 50 times per second (same equations as the Godot trainer), and moves your object to match
  (setPosASL / setVectorDirAndUp, simulation disabled on the object). The brain's whiskers are real
  lineIntersectsSurfaces rays, so it avoids buildings, trees and terrain. If the drone hits something the
  script stops, enables simulation and calls FB_onCrash.

Take-off
  [drone1, target1, 2] call FB_fnc_start;   // climbs to 2 m above the start point, then flies to the target.
  During take-off the ground holds the drone up and the whiskers are off. Landing is not implemented:
  touching the ground or an object later counts as a crash.

Troubleshooting
  [] call FB_fnc_selfTest;   (debug console) checks the data file and runs the brain for 3 simulated seconds.
  Errors are written to the RPT log as lines starting with 'FlyBrain ERROR' and shown in system chat.
  RPT location: C:\Users\<you>\AppData\Local\Arma 3\  (newest .rpt file).

Limits
  * Drone in assist mode only (train it in the Godot app with 'Flight-controller assist' ticked).
  * SQF is slow: keep the brain small. Use 'Small brain preset' in the app, retrain, then export.
    Measure with:  diag_codePerformance [{ [FB_data, FB_inst select 8, FB_inst select 9, _s] call FB_fnc_brainStep }, [], 50]
  * One drone at a time (globals are shared).
  * Singleplayer / local use. In multiplayer run it where the object is local and use enableSimulationGlobal yourself.
